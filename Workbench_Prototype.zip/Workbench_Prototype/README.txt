# Unified Engineering Workbench — Browser Prototype

## Run
1. Extract the ZIP.
2. Open `index.html` in Chrome, Edge or Firefox. No server or installation is required.
3. Navigate between Thermal FEA, Geometry/Files, Parallel Benchmark, Backpropagation and Hardware Mocks.

## Included interactions
- Thermal profile and midpoint interpolation error preview for configurable mesh size.
- Local CSV and ASCII STL file validation.
- Illustrative worker timing table (explicitly estimated, not a real benchmark).
- Backpropagation forward pass, gradients and parameter update.
- Simulated MCU, FPGA and JTAG adapter connection status.

## Limitations
This is a browser prototype, not the standalone C++ application. The thermal view uses the stated analytical field for a demonstration; it is not a general FEA solver. Benchmark values are illustrative estimates, not measured performance. Hardware connections are mocks. STL support counts ASCII facets only; there is no 3D renderer, binary STL support, ANSYS import, or frontend-to-C++ integration. Do not represent these features as completed.
